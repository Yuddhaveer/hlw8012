
////#define GUBED false
#define GUBED   true  
#define DEVICE_ID "40CPA"
String Device_1_Name = "Switch 1 40CPA";
String Uwanxt_1module = "Uwanxt_1Module_40CPA";
#define MQTT_HOST "uwanxt.com"  //MQTT server 
#define MQTT_PORT 9236          //MQTT PORT
#define MQTT_USERNAME "IoTSunKom"   //MQTT username
#define MQTT_PASSWORD "iOtSUnkOM15678132"  //MQTT password
#define MODULE_TYPE 4

#define GPIO16
#define GPIO05
#define GPIO04
#define GPIO13 13 // realy 2 pin
//LED pin
#define LED 14  // LED pin
//BUtton Pins
#define GPIO12 12// Button Pin
//======================================
#define RELAY1 "40CPAa"
#define RELAY1_STATUS "unxt/v1/ha01/40CPAa"
#define ALL_ON "40CPAALLON"
#define ALL_ON_STATUS "unxt/v1/ha01/40CPAALLON"
#define ALL_OFF "40CPAALLOFF"
#define ALL_OFF_STATUS "unxt/v1/ha01/40CPAALLOFF"
// Reset Topic
#define RESET_T "40CPARESET"
// Reboot/Restart Topic
#define REBOOT_T "40CPAREBOOT"
#define ERNGY_S "https://www.uwanxt.com/api/home/api/v3/HAutomate/energyInfo?device_uid=40CPA&voltage=70"
// online offline status
#define ST_PUB_TOPIC "unxt/v1/ha01/st/40CPA" 
#define ST_PUB_TOPIC_2_1_ESP12 "unxt/v1/ha01/st/40CPA"
#define ST_PUB_TOPIC_4_ESP12 "unxt/v1/ha01/st/40CPA"
#define INRESETMODE "5" 
#define WORKINGOK "1" 
#define OFFLINEMODE "2" 
#define INCONFIGMODE "3"
#define INFIRMWAREUPDATEMODE "4"
// EEPROM config address
int configAddress = 3; // in config mode
int rePublishStatus = 8;
